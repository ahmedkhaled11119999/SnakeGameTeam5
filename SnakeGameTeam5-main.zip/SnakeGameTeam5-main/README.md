# Snake Game Team 5 in G1 for ITI 42 InTake - Minia Branch
Javascript game for ITI project
